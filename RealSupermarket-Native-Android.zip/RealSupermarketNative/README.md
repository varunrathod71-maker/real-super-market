# Real Supermarket — Native Android starter

This is a genuine native Android/Kotlin/Jetpack Compose project, not a WebView.

Implemented:
- Red/white supermarket UI
- Customer home
- Typed grocery list
- Weight/quantity choices
- Unknown weight/price
- Review screen
- Free home delivery
- Cash/UPI selection
- Automatic bill
- Order history
- Admin dashboard
- Android 13+ target
- GitHub Actions debug APK workflow

Important architecture note:
This first package keeps order state locally for a fully runnable phone demo. A production multi-device supermarket needs a hosted authenticated backend/database for customers and admins to share live orders. The UI/data models are separated so an API layer can be added without replacing the screens.

## Build with GitHub Actions
1. Create a GitHub repository.
2. Upload this project.
3. Push to `main` or manually run the `Build APK` workflow.
4. Download `RealSupermarket-debug` from the workflow artifacts.

## Build locally
Run:
gradle :app:assembleDebug
