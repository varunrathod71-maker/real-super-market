package com.realsupermarket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

private val Red = Color(0xFFD91E2E)
private val DarkRed = Color(0xFFA91420)
private val SoftRed = Color(0xFFFFF1F2)
private val Ink = Color(0xFF171717)
private val Muted = Color(0xFF6F6F6F)

data class GroceryItem(
    val name: String,
    val weight: String = "",
    val price: String = "",
    val weightUnknown: Boolean = false,
    val priceUnknown: Boolean = false
)

data class Order(
    val code: String,
    val items: List<GroceryItem>,
    val customer: String,
    val phone: String,
    val address: String,
    val fulfillment: String,
    val payment: String,
    val status: String,
    val time: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RealSupermarketApp() }
    }
}

@Composable
fun RealSupermarketApp() {
    var screen by remember { mutableStateOf("home") }
    var orderText by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(listOf<GroceryItem>()) }
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var fulfillment by remember { mutableStateOf("Home delivery") }
    var payment by remember { mutableStateOf("Cash") }
    var orders by remember { mutableStateOf(listOf<Order>()) }
    var latest by remember { mutableStateOf<Order?>(null) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Red,
            onPrimary = Color.White,
            surface = Color.White,
            background = Color(0xFFF8F8F8),
            onSurface = Ink
        )
    ) {
        Scaffold(
            topBar = {
                if (screen != "home") {
                    TopAppBar(
                        title = { Text(
                            when(screen) {
                                "order" -> "Start an Order"
                                "review" -> "Review Order"
                                "checkout" -> "Checkout"
                                "bill" -> "Your Bill"
                                "history" -> "Order History"
                                "admin" -> "Admin Dashboard"
                                else -> "Real Supermarket"
                            }, fontWeight = FontWeight.Bold
                        )},
                        navigationIcon = {
                            IconButton(onClick = { screen = "home" }) {
                                Icon(Icons.Default.ArrowBack, "Back")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Red, titleContentColor = Color.White,
                            navigationIconContentColor = Color.White
                        )
                    )
                }
            },
            bottomBar = {
                if (screen == "home") {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(screen == "home", { screen = "home" },
                            icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                        NavigationBarItem(screen == "history", { screen = "history" },
                            icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Orders") })
                        NavigationBarItem(false, { screen = "admin" },
                            icon = { Icon(Icons.Default.AdminPanelSettings, null) }, label = { Text("Admin") })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFFF8F8F8))) {
                when (screen) {
                    "home" -> HomeScreen({ screen = "order" }, { screen = "history" })
                    "order" -> OrderScreen(
                        orderText, { orderText = it },
                        { 
                            val parsed = it.lines().map { l -> l.replace(Regex("""^\s*[•*\-]\s*"""), "").trim() }
                                .filter { it.isNotBlank() }
                                .map { GroceryItem(it) }
                            items = parsed
                        },
                        items, { items = it }, { screen = "review" }
                    )
                    "review" -> ReviewScreen(items, { screen = "order" }, { screen = "checkout" })
                    "checkout" -> CheckoutScreen(
                        customer, { customer = it }, phone, { phone = it },
                        address, { address = it }, fulfillment, { fulfillment = it },
                        payment, { payment = it }, items,
                        onPlace = {
                            val code = "RS-" + (100000..999999).random()
                            val o = Order(
                                code, items, customer, phone, address, fulfillment, payment,
                                "Order placed", SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                            )
                            orders = listOf(o) + orders
                            latest = o
                            screen = "bill"
                        }
                    )
                    "bill" -> BillScreen(latest, { screen = "home" })
                    "history" -> HistoryScreen(orders)
                    "admin" -> AdminScreen(orders)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(start: () -> Unit, history: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Red),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("REAL SUPERMARKET", color = Color.White, fontWeight = FontWeight.Black, fontSize = 25.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Everything you need, delivered free.", color = Color.White.copy(alpha=.92f), fontSize = 15.sp)
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = start,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Red),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        Icon(Icons.Default.ShoppingCart, null)
                        Spacer(Modifier.width(8.dp))
                        Text("START AN ORDER", fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = SoftRed, shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.LocalShipping, null, tint = Red, modifier = Modifier.padding(12.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("FREE HOME DELIVERY", fontWeight = FontWeight.ExtraBold, color = Ink)
                        Text("No delivery charges on your order.", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
        item {
            Text("Order the easy way", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
            Text("Just type your grocery list. Add weight and price when you know them.", color = Muted)
        }
        item {
            OutlinedButton(
                onClick = history,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.ReceiptLong, null)
                Spacer(Modifier.width(8.dp))
                Text("VIEW ORDER HISTORY", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun OrderScreen(
    text: String, onText: (String) -> Unit, parse: (String) -> Unit,
    items: List<GroceryItem>, setItems: (List<GroceryItem>) -> Unit, next: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("What do you need?", fontSize = 25.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text("Type one grocery item per line.", color = Muted)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { onText(it); parse(it) },
            modifier = Modifier.fillMaxWidth().height(190.dp),
            placeholder = { Text("• 2 kg rice\n• 1 litre sunflower oil\n• 3 packets Parle-G") },
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        if (items.isNotEmpty()) {
            Text("Add details", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                itemsIndexed(items) { index, item ->
                    ItemEditor(item, { updated ->
                        val copy = items.toMutableList(); copy[index] = updated; setItems(copy)
                    })
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }
        Button(
            onClick = next,
            enabled = items.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(15.dp)
        ) { Text("REVIEW & COMPLETE ORDER", fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
fun ItemEditor(item: GroceryItem, update: (GroceryItem) -> Unit) {
    Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(15.dp)) {
            Text("• ${item.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            Text("Weight / quantity", color = Muted, fontSize = 12.sp)
            var expanded by remember { mutableStateOf(false) }
            val options = listOf("250 g","500 g","1 kg","2 kg","5 kg","1 litre","2 litre","1 packet","2 packets","Other")
            Box {
                OutlinedButton(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) { Text(if(item.weightUnknown) "Weight not sure" else item.weight.ifBlank { "Select weight / quantity" }) }
                DropdownMenu(expanded, { expanded = false }) {
                    options.forEach { option ->
                        DropdownMenuItem({ Text(option) }, {
                            expanded = false; update(item.copy(weight=option, weightUnknown=false))
                        })
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(item.weightUnknown, { update(item.copy(weightUnknown=it)) })
                Text("Weight not sure", fontSize = 13.sp)
            }
            OutlinedTextField(
                value = if(item.priceUnknown) "" else item.price,
                onValueChange = { update(item.copy(price=it.filter { c -> c.isDigit() || c=='.' })) },
                enabled = !item.priceUnknown,
                label = { Text("Price ₹") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(item.priceUnknown, { update(item.copy(priceUnknown=it)) })
                Text("I don't know the price", fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun ReviewScreen(items: List<GroceryItem>, edit: () -> Unit, next: () -> Unit) {
    val knownTotal = items.sumOf { if(it.priceUnknown) 0.0 else it.price.toDoubleOrNull() ?: 0.0 }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items) { item ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(item.name, fontWeight = FontWeight.Bold)
                        Text("Weight: " + if(item.weightUnknown) "not sure" else item.weight.ifBlank{"not selected"}, color=Muted)
                        Text("Price: " + if(item.priceUnknown) "To be confirmed" else "₹${item.price}", fontWeight=FontWeight.SemiBold)
                    }
                }
            }
            item {
                Card(shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=SoftRed)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Grocery subtotal", color=Muted)
                        Text(if(items.any{it.priceUnknown}) "₹%.2f + items to be confirmed".format(knownTotal) else "₹%.2f".format(knownTotal),
                            fontSize=22.sp, fontWeight=FontWeight.Black, color=Red)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick=edit, modifier=Modifier.fillMaxWidth().height(50.dp), shape=RoundedCornerShape(14.dp)) {
            Text("EDIT ORDER")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick=next, modifier=Modifier.fillMaxWidth().height(56.dp), shape=RoundedCornerShape(15.dp)) {
            Text("REVIEW & COMPLETE ORDER", fontWeight=FontWeight.ExtraBold)
        }
    }
}

@Composable
fun CheckoutScreen(
    customer: String, setCustomer: (String)->Unit,
    phone: String, setPhone: (String)->Unit,
    address: String, setAddress: (String)->Unit,
    fulfillment: String, setFulfillment: (String)->Unit,
    payment: String, setPayment: (String)->Unit,
    items: List<GroceryItem>, onPlace: ()->Unit
) {
    val total = items.sumOf { if(it.priceUnknown) 0.0 else it.price.toDoubleOrNull() ?: 0.0 }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Delivery & payment", fontSize=23.sp, fontWeight=FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(customer,setCustomer,label={Text("Full name")},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp))
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(phone,setPhone,label={Text("Phone number")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp))
        Spacer(Modifier.height(12.dp))
        Text("Fulfillment",fontWeight=FontWeight.ExtraBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Home delivery","Pickup").forEach { opt ->
                FilterChip(selected=fulfillment==opt,onClick={setFulfillment(opt)},label={Text(opt)},leadingIcon={if(opt=="Home delivery") Icon(Icons.Default.LocalShipping,null)})
            }
        }
        if(fulfillment=="Home delivery") {
            Text("FREE DELIVERY",color=Red,fontWeight=FontWeight.ExtraBold,fontSize=13.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(address,setAddress,label={Text("Delivery address")},modifier=Modifier.fillMaxWidth().height(110.dp),shape=RoundedCornerShape(12.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("Payment",fontWeight=FontWeight.ExtraBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Cash","UPI").forEach { opt -> FilterChip(payment==opt,{setPayment(opt)},label={Text(opt)}) }
        }
        Spacer(Modifier.height(18.dp))
        Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("Estimated total",color=Muted)
                Text(if(items.any{it.priceUnknown}) "₹%.2f + to be confirmed".format(total) else "₹%.2f".format(total),fontSize=26.sp,fontWeight=FontWeight.Black,color=Red)
                Text("Delivery: FREE",color=Muted)
            }
        }
        if(error.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(error,color=Red,fontWeight=FontWeight.Bold) }
        Spacer(Modifier.height(14.dp))
        Button(onClick={
            error = when {
                customer.isBlank() -> "Please enter your name."
                phone.length < 10 -> "Please enter a valid phone number."
                fulfillment=="Home delivery" && address.isBlank() -> "Please enter the delivery address."
                else -> ""
            }
            if(error.isBlank()) onPlace()
        },modifier=Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(15.dp)) {
            Icon(Icons.Default.ArrowForward,null); Spacer(Modifier.width(8.dp))
            Text("PLACE ORDER",fontWeight=FontWeight.ExtraBold)
        }
    }
}

@Composable
fun BillScreen(order: Order?, home: () -> Unit) {
    if(order==null) return
    val total=order.items.sumOf{if(it.priceUnknown)0.0 else it.price.toDoubleOrNull()?:0.0}
    LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item {
            Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Red),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("REAL SUPERMARKET",color=Color.White,fontWeight=FontWeight.Black,fontSize=22.sp)
                    Text("Order ${order.code}",color=Color.White.copy(alpha=.9f))
                    Text(order.time,color=Color.White.copy(alpha=.9f),fontSize=12.sp)
                }
            }
        }
        item { Text("Customer",fontWeight=FontWeight.ExtraBold) }
        item { Text("${order.customer} • ${order.phone}") }
        item { Text(if(order.fulfillment=="Home delivery") "Home delivery • FREE" else "Pickup") }
        items(order.items) { item ->
            Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.fillMaxWidth().padding(15.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name,fontWeight=FontWeight.Bold)
                        Text(if(item.weightUnknown)"Weight not sure" else item.weight,color=Muted,fontSize=12.sp)
                    }
                    Text(if(item.priceUnknown)"To be confirmed" else "₹${item.price}",fontWeight=FontWeight.Bold)
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=SoftRed)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Grocery subtotal",color=Muted)
                    Text("₹%.2f".format(total),fontSize=22.sp,fontWeight=FontWeight.Black)
                    Text("Delivery: FREE",color=Red,fontWeight=FontWeight.Bold)
                    Text(if(order.items.any{it.priceUnknown}) "Grand total: ₹%.2f + to be confirmed".format(total) else "Grand total: ₹%.2f".format(total),
                        fontSize=18.sp,fontWeight=FontWeight.Black)
                }
            }
        }
        item {
            Button(onClick=home,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(14.dp)) {
                Text("BACK TO HOME",fontWeight=FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun HistoryScreen(orders: List<Order>) {
    if(orders.isEmpty()) {
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) { Text("No orders yet.",color=Muted) }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        items(orders) { o ->
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(o.code,fontWeight=FontWeight.ExtraBold,color=Red)
                        Text(o.status,fontWeight=FontWeight.Bold)
                    }
                    Text(o.time,color=Muted,fontSize=12.sp)
                    Text("${o.items.size} item(s) • ${o.fulfillment}")
                    Text("₹%.2f".format(o.items.sumOf{if(it.priceUnknown)0.0 else it.price.toDoubleOrNull()?:0.0}),fontWeight=FontWeight.Black,fontSize=18.sp)
                }
            }
        }
    }
}

@Composable
fun AdminScreen(orders: List<Order>) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Red)) {
                Column(Modifier.padding(20.dp)) {
                    Text("ADMIN DASHBOARD",color=Color.White,fontWeight=FontWeight.Black,fontSize=23.sp)
                    Text("${orders.size} customer order(s)",color=Color.White.copy(alpha=.9f))
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("ORDERS",orders.size.toString(),Modifier.weight(1f))
                StatCard("DELIVERY","FREE",Modifier.weight(1f))
            }
        }
        if(orders.isEmpty()) item { Text("Orders will appear here after customers place them.",color=Muted) }
        items(orders) { o ->
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text(o.code,color=Red,fontWeight=FontWeight.Black)
                    Text(o.customer.ifBlank{"Customer"},fontWeight=FontWeight.Bold)
                    Text("${o.items.size} item(s) • ${o.fulfillment} • ${o.payment}",color=Muted,fontSize=13.sp)
                    Text(o.status,fontWeight=FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun StatCard(title:String,value:String,modifier:Modifier) {
    Card(modifier=modifier,shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(15.dp)) {
            Text(title,color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
            Text(value,color=Red,fontSize=22.sp,fontWeight=FontWeight.Black)
        }
    }
}
